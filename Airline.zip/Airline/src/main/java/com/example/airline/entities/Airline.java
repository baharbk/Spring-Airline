package com.example.airline.entities;


import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@RequiredArgsConstructor
@Entity
@EqualsAndHashCode(callSuper = true)
@Table(name = "AIRLINES")
@ToString
public class Airline extends AppEntity<Long>{

    @Id
    @Column(name = "ID")
    @SequenceGenerator(name = "departmentIdSeq", sequenceName = "DEPARTMENT_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "departmentIdSeq")
    private Long id;

    @Column(name = "Name", insertable = true,nullable = false,updatable = true)
    private String name;
}
