package com.example.airline.entities;

import org.springframework.data.jpa.domain.Specification;

public class AirlineSpecification {

    private AirlineSpecification(){}

    public static Specification <Airline> isEqual (Long id){

        return (((root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("id"), id)));
    }
}
