package com.example.airline.services;

import com.example.airline.dto.ApiResponse;
import com.example.airline.entities.Airline;
import com.example.airline.repositories.AirlineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AirlineService {
    private final AirlineRepository airlineRepository;

    @Autowired
    public AirlineService(AirlineRepository airlineRepository) {
        this.airlineRepository = airlineRepository;
    }

    public ApiResponse getAllAirline(){

        List <Airline> airlines = airlineRepository.findAll();
        return new ApiResponse().addData("Arilines", airlines);
    }

    public Object addAirline(Airline airline){
        return this.airlineRepository.save(airline);
    }

    public ApiResponse updateAirline(Airline airline, long AirlineId){
        Optional <Airline> AirlineFromDb = this.airlineRepository.findById(AirlineId);
        AirlineFromDb.get().setName(airline.getName());
        return new ApiResponse().addData("Airline", airlineRepository.save(AirlineFromDb.get()));
    }

    public ApiResponse deleteAirline(long AirlineId){
        Optional<Airline> AirlineFromDb = this.airlineRepository.findById(AirlineId);
        this.airlineRepository.deleteById(AirlineId);
        return new ApiResponse().addData("success",true);
    }
}
