package com.example.airline.controllers;

import com.example.airline.dto.ApiResponse;
import com.example.airline.entities.Airline;
import com.example.airline.services.AirlineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class AirlineController {

    private final AirlineService airlineService;

    @Autowired
    public AirlineController(AirlineService airlineService) {
        this.airlineService = airlineService;
    }

    @GetMapping("airline/get/all")
    public ApiResponse getAllAirline(){

        return airlineService.getAllAirline();
    }

    @PostMapping("airline/add")
    public Object addAirline(@RequestBody Airline department){
        return airlineService.addAirline(department);
    }


    @PutMapping("airline/update/{AirlineId}")
    public ApiResponse updateAirline(@RequestBody Airline department, @PathVariable Long AirlineId){

        return airlineService.updateAirline(department, AirlineId);
    }

    @DeleteMapping("department/delete/{AirlineId}")
    public ApiResponse deleteAirline(@PathVariable Long AirlineId){

        return airlineService.deleteAirline(AirlineId);
    }
}
