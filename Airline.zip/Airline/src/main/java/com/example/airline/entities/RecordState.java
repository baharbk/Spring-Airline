package com.example.airline.entities;

public enum RecordState {
    ACTIVE, INACTIVE, DELETED
}
