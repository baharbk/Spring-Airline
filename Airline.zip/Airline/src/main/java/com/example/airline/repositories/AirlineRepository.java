package com.example.airline.repositories;

import com.example.airline.entities.Airline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;

public interface AirlineRepository extends JpaRepository<Airline,Long>, JpaSpecificationExecutor<Airline> {

    List<Airline> findAllByName (String name);

    Optional<Airline> findById (Long Id);

}
